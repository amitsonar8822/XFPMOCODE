#!/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to resource_user_group_role API and get a response.Panda library used to convert response to CSV file
#
#Date:23/12/2020
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg=sys.argv[1]

print('InputPath: %s' %firstarg)


url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

payload="{\r\n  \"content\": {\r\n    \"columnnames\": [\r\n      \"sys_id\",\r\n\"portfolio\",\r\n\"task\",\r\n\"fiscal_period\",\r\n\"capex_budget\",\r\n\"opex_budget\",\r\n\"budget\",\r\n\"capex_target\",\r\n\"opex_target\",\r\n\"state\",\r\n\"target\",\r\n\"sys_updated_on\",\r\n\"sys_updated_by\",\r\n\"sys_mod_count\",\r\n\"sys_created_on\",\r\n\"sys_created_by\"\r\n    ],\r\n    \"query\": \"''\",\r\n    \"tablename\": \"project_funding\"\r\n  },\r\n  \"header\": {\r\n    \"sourcesystemid\": \"IDW\",\r\n    \"targetsystemid\": \"GODW\"\r\n  }\r\n}"
headers = {
  'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
  'Content-Type': 'application/json',
  'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w=',
  'Cookie': 'glide_user_route=glide.682dea81f49c65ab9e36110a1abb3c0a; BIGipServerpool_roche=2575425290.36158.0000; JSESSIONID=9D48F792A957E82E564517DF302275D2; glide_session_store=C14640091B91E4D0488062CCAB4BCBF1'
}

response = requests.request("POST", url, headers=headers, data=payload)

json_data = json.loads(response.text.encode('utf8'))
df = json_normalize(json_data['result']['data'])

df.to_csv(r'%s/SrcFiles/API_SRC/Project_funding.csv' %firstarg
          , index=False, header=True)
