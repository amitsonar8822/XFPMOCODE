#!/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to Generic API API and get a response.Panda library used to convert response to CSV file
#
#Date:11/05/2021
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg=sys.argv[1]


print('InputPath: %s' %firstarg)

url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

payload = json.dumps({
  "content": {
    "columnnames": [
      "fiscal_period",
      "variance",
      "sys_mod_count",
      "sys_updated_by",
      "sys_updated_on",
      "task",
      "sys_tags",
      "reference_rate",
      "program",
      "portfolio",
      "base_estimated_benefit",
      "exchange_rate_date",
      "exchange_rate",
      "entered_currency",
      "sys_domain",
      "sys_created_by",
      "sys_created_on",
      "estimated_benefit",
      "actual_benefit",
      "benefit_plan",
      "sys_id"
    ],
    "query": "sys_idISNOTEMPTY",
    "tablename": "benefit_plan_breakdown",
    "reclimit": 50000,
    "recoffset": "1"
  },
  "header": {
    "sourcesystemid": "IDW",
    "targetsystemid": "GODW"
  }
})
headers = {
  'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
  'Content-Type': 'application/json',
  'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w=',
}

response = requests.request("POST", url, headers=headers, data=payload)

json_data = json.loads(response.text.encode('utf8'))
df = json_normalize(json_data['result']['data'])

df.to_csv(r'%s/SrcFiles/API_SRC/Benefit_plan_breakdown.csv' %firstarg
          , index=False, header=True)

print("Benefit_plan_breakdown.csv is created successfully")
