#!/bin/bash

#################################################################################################################
# Description: This script has been created to call getProjectsMethod to get list of projects based on criteria
# ENV: TEST
# Author: Amit Sonar
# Date: 27/03/2020
#################################################################################################################


fp=`echo $(pwd)|cut -d'/' -f3`

echo "$1"

source $1/ParFiles/API_param.conf

buffer_date=$(date +%Y-%m-%d -d "$BUFF_CRITERIA")

# Calculating 5 days back for data fetching

echo "updated_date":"$buffer_date"

curl --location --request POST "$getProjectsUrl" \
--header 'Content-Type: application/json' \
--header 'Api-Key: '"$APIKEY_PRD"'' \
--header 'Authorization: Basic '"$AUTHKEY"'' \
--data '{
"content": {
"active": ["true","false"]
},
"header": {
"sourcesystemid": "'"$SOURCESYSTEMID"'",
"recoffset" : 0,
"reclimit" : 100000
}
}' | sed 's/"number"/\n"number"/g' \
  |grep '"number"' \
  |awk -F',' '{print $1}'|cut -d'"' -f 4 > $1/SrcFiles/API_SRC/FULL_ProjectList.dat


