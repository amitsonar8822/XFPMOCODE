#!/bin/bash

#################################################################################################################
# Description: This script has been created to call getProjectsMethod to get list of projects based on criteria
# ENV: TEST
# Author: Amit Sonar
# Date: 27/03/2020
#################################################################################################################

source $1/ParFiles/API_param.conf

buffer_date=$(date +%Y-%m-%d -d "$BUFF_CRITERIA")

curl --location --request POST "$getProgramsUrl" \
--header 'Content-Type: application/json' \
--header 'Api-Key: '"$APIKEY_PRD"'' \
--header 'Authorization: Basic '"$AUTHKEY"'' \
--data '{
"content": {
"active": "true"
},
"header": {
"sourcesystemid": "'"$SOURCESYSTEMID"'",
"recoffset" : 0,
"reclimit" : 100000
}
}' | grep -o '\bPGM\w*' > $1/SrcFiles/API_SRC/ProgramList.dat
