#!/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to Resource_plan API and get a response.Panda library used to convert response to CSV file
#
#Date:17/12/2020
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg=sys.argv[1]

print('InputPath: %s' %firstarg)

url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

payload="{\r\n  \"content\": {\r\n    \"columnnames\": [\r\n      \"number\",\"name\",\"task\",\"group\",\"fte\",\"top_task\",\"start_date\",\"end_date\",\"planned_hours\",\"state\",\"role\",\"resource_type\",\"request_type\",\"group_resource\"\r\n    ],\r\n    \"query\": \"numberISNOTEMPTY\",\r\n    \"tablename\": \"resource_plan\",\r\n    \"reclimit\": \"10000000\"\r\n  },\r\n  \"header\": {\r\n    \"sourcesystemid\": \"IDW\",\r\n    \"targetsystemid\": \"SNOW\"\r\n  }\r\n}\r\n"
headers = {
  'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
  'Content-Type': 'application/json',
  'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w=',
  'Cookie': 'glide_user_route=glide.702277270457deec6512ea182aadab19; BIGipServerpool_roche=2457919242.33086.0000; JSESSIONID=CDE8BB43FCAF71EF125A3409AE319445; glide_session_store=39810B9ADB012450F2450028F496194D'
}

response = requests.request("POST", url, headers=headers, data=payload)

json_data = json.loads(response.text.encode('utf8'))
df = json_normalize(json_data['result']['data'])

df.to_csv(r'%s/SrcFiles/API_SRC/Resource_plan.csv' %firstarg
          , index=False, header=True)
