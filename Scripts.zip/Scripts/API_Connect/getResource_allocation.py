#!/usr/bin/env python
# coding: utf-8

# In[1]:


#!/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to Resource_allocation API and get a response.Panda library used to convert response to CSV file
#
#Date:22/12/2020
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg=sys.argv[1]

loopID=1
recordExist=True

reclimit=10000
recoffset=1

print('InputPath: %s' %firstarg)


url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

while recordExist:
    print(loopID,recordExist,recoffset,reclimit)
    payload="{\r\n  \"content\": {\r\n    \"columnnames\": [\r\n      \"end_date\",\r\n\"requested_man_days\",\r\n\"sys_domain\",\r\n\"task\",\r\n\"actual_hours\",\r\n\"requested_fte\",\r\n\"sys_created_by\",\r\n\"sys_updated_by\",\r\n\"assigned_cost\",\r\n\"number\",\r\n\"sys_id\",\r\n\"distribution_type\",\r\n\"requested_hours\",\r\n\"sys_created_on\",\r\n\"sys_updated_on\",\r\n\"actual_cost\",\r\n\"assigned_hours\",\r\n\"requested_cost\",\r\n\"start_date\",\r\n\"sys_mod_count\",\r\n\"allocated_hours\",\r\n\"allocated_cost\",\r\n\"resource_plan\",\r\n\"user\",\r\n\"booking_type\",\r\n\"user.user_name\"\r\n    ],\r\n    \"query\": \"numberISNOTEMPTY\",\r\n    \"tablename\": \"resource_allocation\",\r\n    \"reclimit\": \""+str(reclimit)+"\",\r\n  \"recoffset\": \""+str(recoffset)+"\"\r\n  },\r\n  \"header\": {\r\n    \"sourcesystemid\": \"IDW\",\r\n    \"targetsystemid\": \"SNOW\"\r\n  }\r\n}\r\n"
    headers = {
      'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
      'Content-Type': 'application/json',
      'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w=',
      'Cookie': 'glide_user_route=glide.682dea81f49c65ab9e36110a1abb3c0a; BIGipServerpool_roche=2575425290.36158.0000; JSESSIONID=B91D59841362CBA84F3DDC1BAC2A6321'
    }
    response = requests.request("POST", url, headers=headers, data=payload)

    json_data = json.loads(response.text.encode('utf8'))
    df = json_normalize(json_data['result']['data'])
    
    if loopID==1:
        result=df
    #    df = json_normalize(json_data['result']['data'])
    #    print("DF1 ",str(df['number'].count()))
    #    result = df
    else:
        result = result.append(df)
    #    df2 =json_normalize(json_data['result']['data'])
    #    if loopID==2:
    #        result=df.append(df2)
    #    else:
    #        result = result.append(df2)
    #    print("DF2: ",str(df2['number'].count())," DF R: ",str(result['number'].count()))
    
    recNum = json_data['result']['recCount']
    
    if recNum<1:
        recordExist = False
    recoffset=reclimit*loopID+1
    loopID=loopID+1
    
    
result.drop_duplicates()
result.to_csv(r'%s/SrcFiles/API_SRC/Resource_allocation.csv' %firstarg
          , index=False, header=True)
#result.to_csv(r'C:\Users\liwiakm\Desktop\APIs\All\CSV_PROD\RMCHECK.csv',index = False,header=True)


# In[3]:


result['number'].count()


# In[94]:


recoffset


# In[ ]:




