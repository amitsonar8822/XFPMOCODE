#!/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to resource_user_group_role API and get a response.Panda library used to convert response to CSV file
#
#Date:23/12/2020
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg=sys.argv[1]

print('InputPath: %s' %firstarg)


url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

payload="{\r\n  \"content\": {\r\n    \"columnnames\": [\r\n      \"grpmember_group\",\r\n\"grpmember_user\",\r\n\"usr_user_name\",\r\n\"urr_role\",\r\n\"urr_sys_domain\",\r\n\"usr_sys_id\",\r\n\"urr_user\",\r\n\"urr_user.manager\",\r\n\"usr_location\",\r\n\"usr_name\",\r\n\"grpmember_user.active\",\r\n\"grpmember_user.department\",\r\n\"grpmember_group.manager\",\r\n\"grpmember_user.u_employee_type\"\r\n    ],\r\n    \"query\": \"grpmember_groupLIKEpi chapter^ORgrpmember_groupSTARTSWITHerp^ORgrpmember_groupSTARTSWITHgis ^ORgrpmember_groupSTARTSWITHdia_\",\r\n    \"tablename\": \"resource_user_group_role\"\r\n  },\r\n  \"header\": {\r\n    \"sourcesystemid\": \"IDW\",\r\n    \"targetsystemid\": \"GODW\"\r\n  }\r\n}"
headers = {
  'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
  'Content-Type': 'application/json',
  'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w=',
  'Cookie': 'glide_user_route=glide.682dea81f49c65ab9e36110a1abb3c0a; BIGipServerpool_roche=2575425290.36158.0000; JSESSIONID=9D48F792A957E82E564517DF302275D2; glide_session_store=C14640091B91E4D0488062CCAB4BCBF1'
}

response = requests.request("POST", url, headers=headers, data=payload)

json_data = json.loads(response.text.encode('utf8'))
df = json_normalize(json_data['result']['data'])

df.to_csv(r'%s/SrcFiles/API_SRC/Resource_user_group_role.csv' %firstarg
          , index=False, header=True)
