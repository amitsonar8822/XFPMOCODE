#!/usr/bin/env python3
 -*- coding: utf-8 -*-

import requests
import json
from pandas.io.json import json_normalize

url =     'https://send-tst.roche.com/api/ServiceNow/ppm_project/v1.0/ppm_project/getProjectsMethod'

payload =     '''{\r
"content": {\r
"active": "true"\r
\r
},\r
"header": {\r
"sourcesystemid": "IDW",\r
"recoffset" : 0,\r
"reclimit" : 100000\r
}\r
}\r
'''
headers = {
    'Content-Type': 'application/json',
    'API-Key': '61567f67-ba26-4d09-aa12-8c5806204f9a',
    'Authorization': 'Basic aW50Z3JvdW06WEZQTU8yMDIwYXNk',
    'Content-Type': 'application/json',
    'Cookie': 'glide_user_route=glide.5cfeac75fa0910001c4fc0a33c8ec5fe; BIGipServerpool_rochesat=2374033162.35390.0000; JSESSIONID=B7BBFC4D94FF629DD018C01DD18FA75B; glide_session_store=9333D469DB3BC0102D4AE984059619BA',
    }

response = requests.request('POST', url, headers=headers, data=payload)
json_data = json.loads(response.text.encode('utf8'))
df = json_normalize(json_data['result']['projects'])


i = True
for x in df['number']:
    url2 =         'https://send-tst.roche.com/api/ServiceNow/ppm_project/v1.0/ppm_project/getProjectMethod'
    payload2 = "{\r\n  \"content\": {\r\n      \"number\": \""+x+"\"\r\n  },\r\n  \"header\": {\r\n      \"sourcesystemid\": \"PRED-MORPH\"\r\n  }\r\n}\r\n\r\n"
    headers2 = {
        'Content-Type': 'application/json',
        'API-Key': '61567f67-ba26-4d09-aa12-8c5806204f9a',
        'Authorization': 'Basic aW50Z3JvdW06WEZQTU8yMDIwYXNk',
        'Content-Type': 'application/json',
        'Cookie': 'glide_user_route=glide.5cfeac75fa0910001c4fc0a33c8ec5fe; BIGipServerpool_rochesat=2374033162.35390.0000; JSESSIONID=33F538CD59D293287ED8FF853F18AC78; glide_session_store=8FB5C7D9DBFB80102D4AE98405961958; glide_user=U0N2MzpxdnRRS1hHV3Naa0ROdEV2YkpUV3VIWW1PMFBwbEtEYTpMUDZUbFc3TzBUaUhFaDB4c25sUzdobmVJRFRrV2J6aWdFOHRZTmtvQmNJPQ==; glide_user_session=U0N2MzpxdnRRS1hHV3Naa0ROdEV2YkpUV3VIWW1PMFBwbEtEYTpMUDZUbFc3TzBUaUhFaDB4c25sUzdobmVJRFRrV2J6aWdFOHRZTmtvQmNJPQ==',
        }

    response2 = requests.request('POST', url2, headers=headers2,
                             data=payload2)
    json_data2 = json.loads(response2.text.encode('utf8'))
    if i:
        df2 = json_normalize(json_data2['result'])
        i = False
    else:
        df3 = json_normalize(json_data2['result'])
        df2 = df2.append(df3)

df2.to_csv(r'/infa_shared/INT_GRD_DEV/OSP_DIR/idw0428/Api/PROJECT.csv',index=False, header=True)

