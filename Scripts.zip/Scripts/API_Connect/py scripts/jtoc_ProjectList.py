#!/usr/bin/env python

import csv
import json
import io
PYTHONIOENCODING="UTF-8"

with open ('/infa_shared/INT_GRD_DEV/OSP_DIR/idw0428/Api/ProjectList.json') as f:
    data=json.load(f)
for contents in data['result']:
    rows_header_list=(list(contents.keys()))
       
with io.open('/infa_shared/INT_GRD_DEV/OSP_DIR/idw0428/Api/ProjectList.csv', 'wb') as outfile:
        csv_dict_file_writer = csv.DictWriter(outfile, fieldnames=rows_header_list)
        headers = {}
        for n in csv_dict_file_writer.fieldnames:
          headers[n] = n

            # Write csv file header field names.
        csv_dict_file_writer.writerow(headers)    
with open('/infa_shared/INT_GRD_DEV/OSP_DIR/idw0428/Api/ProjectList.csv', 'ab') as outfile:
        writer = csv.DictWriter(outfile,fieldnames=rows_header_list)
        for contents in data['result']:
                  writer.writerow(contents)