#!/usr/bin/python3
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to Resource_plan API and get a response.Panda library used to convert response to CSV file
#
#Date:17/12/2020
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
# from API_param.conf import getGenericAPIURL
from pandas.io.json import json_normalize
import os
import glob

firstarg=sys.argv[1]

#Emptying the CostPlanParts directory

rfiles = glob.glob(sys.argv[1]+'/SrcFiles/API_SRC/CostPlanParts/*')
for f in rfiles:
    os.remove(f)




print('InputPath: %s' %firstarg)

# print getGenericAPIURL

resultLimit=10000
temp=0
for x in range(1,61):
	readStart=1+temp
	print('%s' %readStart)

	url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

	payload=("{\r\n    \"content\": {\r\n        \"columnnames\": [\r\n            \"sys_id\",\r\n            \"breakdown_type\",\r\n            \"expense_type\",\r\n            \"fiscal_period\",\r\n            \"task\",\r\n            \"portfolio\",\r\n            \"program\",\r\n            \"cost_local_currency\",\r\n            \"cost_default_currency\",\r\n            \"actual\",\r\n            \"budget\",\r\n            \"cost_plan\",\r\n            \"sys_created_on\",\r\n            \"sys_created_by\",\r\n            \"entered_currency\",\r\n            \"exchange_rate\",\r\n            \"exchange_rate_date\",\r\n            \"target\",\r\n            \"sys_updated_on\",\r\n            \"sys_updated_by\",\r\n            \"variance\",\r\n        \"cost_plan.u_task_ops\"\r\n        ],\r\n        \"query\": \"sys_idISNOTEMPTY^fiscal_periodLIKEFY2\",\r\n        \"tablename\": \"cost_plan_breakdown\",\r\n        \"reclimit\": %d,\r\n        \"recoffset\": %d\r\n    },\r\n    \"header\": {\r\n        \"sourcesystemid\": \"IDW\",\r\n        \"targetsystemid\": \"SNOW\"\r\n    }\r\n}" %(resultLimit,readStart))
	headers = {
	'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
	'Content-Type': 'application/json',
	'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w='
	}

	print(payload)
	response = requests.request("POST", url, headers=headers, data=payload)

	print(response)
	json_data = json.loads(response.text.encode('utf8'))
	df = json_normalize(json_data['result']['data'])
	DynFileName='Cost_plan_breakdown_'+ str(readStart) +'.csv'
	
	df.to_csv(r'%s/SrcFiles/API_SRC/CostPlanParts/%s'  %(firstarg,DynFileName)
      , index=False, header=True)
	# print("New file created: "+DynFileName)
	temp=temp+resultLimit
	
f = open(sys.argv[1]+'/SrcFiles/API_SRC/CostPlanParts/CostPlanFileList.txt','w',encoding = 'utf-8')
fpath=sys.argv[1]+'/SrcFiles/API_SRC/CostPlanParts'

#Writing a FileList for informatica
print("Writing a FileList for informatica")

with os.scandir(fpath) as listOfEntries:
	for entry in listOfEntries:
		if entry.name.endswith('.csv'):
		#	print(fpath+entry.name)
			f.write(fpath+ '/' +entry.name+'\n') 
print("filelist is ready")
f.close()



