#!/bin/bash



func_process_object () {
	echo "******** "$1
	local FILE_ID=$1
	local TARGET=$2
	
	local IFS=','
	local MSG=$(curl --silent -L --header "Authorization: Bearer $ACCESS_TOKEN" "https://www.googleapis.com/drive/v2/files/$FILE_ID?fields=mimeType%2Ctitle%2CdownloadUrl" | sed ':a;N;$!ba;s/\n//g'  | sed 's/" \+/"/g'  | sed 's/ \+"/"/g' | sed 's/[{}]//g')
	
	echo $MSG
	
	for tokens in $MSG;
	do
		local TOKEN1=$(echo $tokens | grep -Po '".+":'  | sed 's/[":]//g')
		local TOKEN2=$(echo $tokens | grep -Po ':".+"'  | sed 's/["]//g' | sed 's/^://g')

		if [ $TOKEN1 = "title" ]
		then
			local TITLE=$TOKEN2
		elif [ $TOKEN1 = "mimeType" ]
		then
			local MIME=$TOKEN2
		elif [ $TOKEN1 = "downloadUrl" ]
		then
			local DOWNLOAD_LINK=$TOKEN2
		fi
	done

	if [ $FILE_ID = 'root' ]
	then
		TITLE='.'
		MIME='application/vnd.google-apps.folder'
	fi
	echo $TITLE
	echo $MIME

	if [ $MIME = "application/vnd.google-apps.spreadsheet" ] 
	then 
		echo "FILE"
		echo $TARGET
		func_download_spreadsheet $FILE_ID $TITLE $TARGET
	elif [ $MIME = "text/plain" ] || [ $MIME = "text/csv" ] || [ $MIME = "application/octet-stream" ]
	then 
		echo "TEXT FILE"
		echo $TARGET
		func_download_text_file $FILE_ID $TITLE $TARGET $DOWNLOAD_LINK
	elif [ $MIME = "application/vnd.google-apps.folder" ]
	then
		echo "FOLDER"
		
	if [ ! -d $2"/"$TITLE ];
	then
		mkdir $2"/"$TITLE
		
	fi
	local IFS=$'\n'
	RESP2=$(curl --silent -L --header "Authorization: Bearer $ACCESS_TOKEN" "https://www.googleapis.com/drive/v2/files/$FILE_ID/children?fields=items%2Fid" | sed ':a;N;$!ba;s/\n//g' | sed 's/{/ /g' | sed 's/}/ /g' | sed 's/ \+"/"/g' | sed 's/" \+/"/g' | sed 's/: /:/g' | sed 's/"//g' | sed 's/items://g' | sed 's/\[//g' | sed 's/\]//g' | sed 's/ //g')
	
	local IFS=','
	local TARGET2=$TARGET"/"$TITLE
	for tokens in $RESP2;
	do
	TOKEN1=`echo $tokens | cut -d \: -f 1`
	TOKEN2=`echo $tokens | cut -d \: -f 2`
	if [ $TOKEN1 = "id" ]
	then
	
	func_process_object $TOKEN2 $TARGET2
	
	fi
	done

fi
MIME='application/vnd.google-apps.folder' 
echo $MIME
}

func_download_spreadsheet () {

local NAME=$2
local TARGET=$3

local MSG=$(curl --silent -L --header "Authorization: Bearer $ACCESS_TOKEN" "https://spreadsheets.google.com/feeds/worksheets/$1/private/full?alt=json" | grep -Po 'export\?gid\\u003d[^\\]*' | sed 's/export?gid\\u003d//g')

local IFS=$'\n'
local number=0
for token in $MSG;
do
	((number+=1))
done
local i=1
for token in $MSG;
do
	if [ $number -ne 1 ]
	then
	local sufix="_"$i
	else
	sufix=""
	fi
	curl --silent --retry 5 -L --header "Authorization: Bearer $ACCESS_TOKEN" "https://spreadsheets.google.com/feeds/download/spreadsheets/Export?key=$1&gid=$token&exportFormat=$FORMAT" > $TARGET"/"$NAME$sufix
	((i+=1))	
done
}


func_download_text_file () {
	local TARGET=$3
	curl --silent -L --header "Authorization: Bearer $ACCESS_TOKEN" "$4" > $TARGET"/"$2
}


func_connect () {
	local CLIENT_ID="378344054187-8upf4vg426vv9nak94ssu6ec424lae9d.apps.googleusercontent.com"
	local CLIENT_SECRET="7qaDw0T8OH27-WSmLaalIEgD"
	
	TOKEN=""
	SOURCE=""
	TARGET=""
	FORMAT=""
	
	local TOKEN_SET=false
	local SOURCE_SET=false
	local TARGET_SET=false
	local FORMAT_SET=false
	
	for line in $(cat $1) 
	do 
		local TOKEN1=`echo $line | cut -d \= -f 1`
		local TOKEN2=`echo $line | cut -d \= -f 2`
		if [ $TOKEN1 = "TOKEN" ]
		then
			TOKEN=$TOKEN2
			TOKEN_SET=true
		elif [ $TOKEN1 = "SOURCE" ]
		then 
			SOURCE=$TOKEN2
			SOURCE_SET=true
		elif [ $TOKEN1 = "TARGET" ]
		then 
			TARGET=$TOKEN2
			TARGET_SET=true
		elif [ $TOKEN1 = "FORMAT" ]
		then 
			FORMAT=$TOKEN2
			FORMAT_SET=true
		fi
	done

	if [ $TOKEN_SET = true ]
	then
		local MSG=$(curl -X POST  -s -d "client_id=$CLIENT_ID&client_secret=$CLIENT_SECRET&refresh_token=$TOKEN&grant_type=refresh_token" https://accounts.google.com/o/oauth2/token | sed ':a;N;$!ba;s/\n//g' | sed 's/{/ /g' | sed 's/}/ /g' | sed 's/ \+"/"/g' | sed 's/" \+/"/g' | sed 's/: /:/g' | sed 's/"//g') 
		local IFS=','
		for word in $MSG;
		do
			local TOKEN1=`echo $word | cut -d \: -f 1`
			local TOKEN2=`echo $word | cut -d \: -f 2`
			if [ $TOKEN1 = "access_token" ] && [ ! -z $TOKEN2 ] 
			then
				ACCESS_TOKEN=$TOKEN2
				local ACCESS_TOKEN_SET=true
			elif [ $TOKEN1 = "error" ]
			then 
				local MSG_2=$(curl -X POST -s -d "code=$TOKEN&client_id=$CLIENT_ID&client_secret=$CLIENT_SECRET&redirect_uri=urn:ietf:wg:oauth:2.0:oob&grant_type=authorization_code" https://accounts.google.com/o/oauth2/token | sed ':a;N;$!ba;s/\n//g' | sed 's/{/ /g' | sed 's/}/ /g' | sed 's/ \+"/"/g' | sed 's/" \+/"/g' | sed 's/: /:/g' | sed 's/"//g')
				local IFS=','
				for word in $MSG_2;
				do
					local TOKEN1_2=`echo $word | cut -d \: -f 1`
					local TOKEN2_2=`echo $word | cut -d \: -f 2`
					if [ $TOKEN1_2 = "access_token" ] && [ ! -z $TOKEN2_2 ] 
					then
						ACCESS_TOKEN=$TOKEN2_2
						local ACCESS_TOKEN_SET=true
					elif [ $TOKEN1_2 = "refresh_token" ] 
					then 
						REFRESH_TOKEN=$TOKEN2_2
						local REFRESH_TOKEN_SET=true
						sed -i "s:TOKEN=.*:TOKEN=$REFRESH_TOKEN:" $1
					fi
				done
			fi
		done
		if [ $ACCESS_TOKEN_SET = true ]
		then
			echo "LOGIN SUCCESSFUL"
		fi
	fi
 
}



func_connect $1

IFS=','

for id in $SOURCE;
do
	func_process_object $id $TARGET
done


