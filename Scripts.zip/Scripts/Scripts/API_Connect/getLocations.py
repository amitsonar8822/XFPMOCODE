#!/usr/bin/python
# -*- coding: utf-8 -*-

import requests
import json
from pandas.io.json import json_normalize

url = \
    'https://send.roche.com/api/ServiceNow/ppm_locations_affected/v1.0/ppm_locations_affected/getLocationsAffectedMethod'

payload = \
    '''\r
{\r
"content": {\r
"active": "true"\r
},\r
"header": {\r
"sourcesystemid": "IDW",\r
"recoffset" : 0,\r
"reclimit" : 10000\r
}\r
}\r
'''
headers = {
    'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
    'Content-Type': 'application/json',
    'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w=',
    'Cookie': 'JSESSIONID=9A04C907860B41AD4626052FCDAE3953; glide_user_route=glide.00755cd0c221150d8958ab2f1a757936; glide_session_store=A8CADBABDB0E9450DDBF13853296197F; BIGipServerpool_roche=193060362.35646.0000',
    }

response = requests.request('POST', url, headers=headers, data=payload)

json_data = json.loads(response.text.encode('utf8'))
df = json_normalize(json_data['result']['tasks'])

df.to_csv(r'/infa_shared/INT_GRD_TEST/OSP_DIR/idw0428/SrcFiles/API_SRC/Locations.csv'
          , index=False, header=True)
