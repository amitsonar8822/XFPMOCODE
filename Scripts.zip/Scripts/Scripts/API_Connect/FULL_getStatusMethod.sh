#!/bin/bash

#################################################################################################################
# Description: This script has been created to call getStatusMethod to get full list of status based on criteria
# ENV: TEST
# Author: Amit Sonar
# Date: 22/05/2020
#################################################################################################################


fp=`echo $(pwd)|cut -d'/' -f3`

echo "/infa_shared/$fp/OSP_DIR/idw0428/ParFiles/API_param.conf"

source $1/ParFiles/API_param.conf

buffer_date=$(date +%Y-%m-%d -d "$BUFF_CRITERIA")

# Calculating 5 days back for data fetching

echo "updated_date":"$buffer_date"

curl --location --request POST "$getStatusUrl" \
--header 'Content-Type: application/json' \
--header 'Api-Key: '"$APIKEY_PRD"'' \
--header 'Authorization: Basic '"$AUTHKEY"'' \
--data '{
"content": {
"active": ["true","false"]
},
"header": {
"sourcesystemid": "'"$SOURCESYSTEMID"'",
"recoffset" : 0,
"reclimit" : 100000
}
}' | grep -o '\bPRJSTAT\w*' > $1/SrcFiles/API_SRC/FULL_StatusList.dat

