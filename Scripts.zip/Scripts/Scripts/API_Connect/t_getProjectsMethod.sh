#!/bin/bash

#################################################################################################################
# Description: This script has been created to call getProjectsMethod to get list of projects based on criteria
# ENV: TEST
# Author: Amit Sonar
# Date: 27/03/2020
#################################################################################################################

source /infa_shared/INT_GRD_DEV/OSP_DIR/idw0428/ParFiles/API_param.conf


curl --location --request POST "$getProjectsUrl" \
--header 'Content-Type: application/json' \
--header 'Api-Key: '"$APIKEY_TEST"'' \
--header 'Authorization: Basic '"$AUTHKEY"'' \
--data '{
"content": {
"active": "true"
},
"header": {
"sourcesystemid": "'"$SOURCESYSTEMID"'",
"recoffset" : 0,
"reclimit" : 100000
}
}' | sed 's/"number"/\n"number"/g' \
  |grep '"number"' \
  |awk -F',' '{print $1}'|cut -d'"' -f 4 > /infa_shared/INT_GRD_DEV/OSP_DIR/idw0428/SrcFiles/API_SRC/ProjectList.dat
