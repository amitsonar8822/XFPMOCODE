#!/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to Resource_plan API and get a response.Panda library used to convert response to CSV file
#
#Date:17/12/2020
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg=sys.argv[1]

print('InputPath: %s' %firstarg)

url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

payload = json.dumps({
  "content": {
    "columnnames": [
      "task",
      "group_resource",
      "user_resource",
      "percent_capacity",
      "percent_allocated",
      "actual_cost",
      "actual_hours",
      "distribution_type",
      "assigned_cost",
      "assigned_hours",
      "u_business_unit",
      "allocated_cost",
      "allocated_hours",
      "allocated_members_list",
      "sys_created_on",
      "sys_created_by",
      "sys_domain",
      "extension",
      "extension_request_type",
      "extension_start_date",
      "extension_value",
      "fte",
      "members_list",
      "members_preference",
      #"notes",
      #"notes_list",
      "operational_work_type",
      "man_days",
      "plan_type",
      "u_annualized_fte",
      "portfolio",
      "program",
      "rate_model",
      "rate_override",
      "request_type",
      "resource_rate",
      "resource_type",
      "role",
      "is_roll_up_from_allocations",
      "skills",
      "state_change_from_raw",
      "sys_tags",
      "top_task",
      "sys_updated_on",
      "sys_updated_by",
      "sys_mod_count",
      "distribution",
      "state",
      "planned_cost",
      "planned_hours",
      "end_date",
      "start_date",
      "short_description",
      "number",
      "sys_id"
    ],
    "query": "allocation_typeLIKEPlan",
    "tablename": "resource_plan",
    "reclimit": "50000"
  },
  "header": {
    "sourcesystemid": "IDW",
    "targetsystemid": "SNOW"
  }
})

headers = {
  'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
  'Content-Type': 'application/json',
  'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w=',
  'Cookie': 'glide_user_route=glide.702277270457deec6512ea182aadab19; BIGipServerpool_roche=2457919242.33086.0000; JSESSIONID=CDE8BB43FCAF71EF125A3409AE319445; glide_session_store=39810B9ADB012450F2450028F496194D'
}

response = requests.request("POST", url, headers=headers, data=payload)


json_data = json.loads(response.text)

df = json_normalize(json_data['result']['data'])

print(type(json_data))
print(type(response))
#print(type(tm))

df.to_csv(r'%s/SrcFiles/API_SRC/Resource_plan.csv' %firstarg
          , index=False, header=True)
