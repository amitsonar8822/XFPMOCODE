import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg = sys.argv[1]

loopCount = 0
appKey = 'b4ea648c-f44a-4d53-925d-7b208985d34a'
appAuth = 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w='
appContentType = 'application/json'
# print('InputPath: %s' %firstarg)
url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"
resultLimit = 3000
temp = 0
for x in range(1, 150):
    readStart = 1 + temp
    payload = json.dumps({
        "content": {
            "columnnames": [
                "sys_id",
                "name",
                "sys_class_name",
                "operational_status",
                "used_for",
                "busines_criticality",
                "u_support_level",
                "service_classification",
                "owned_by",
                "managed_by",
                "x_avne2_atri_to_sn_active",
                "aliases",
                "change_control",
                "asset",
                "asset_tag",
                "assigned",
                "assigned_to",
                "attestation_score",
                "attested",
                "attested_by",
                "attested_date",
                "attributes",
                "business_contact",
                "business_need",
                "business_relation_manager",
                "u_business_unit",
                "u_ci_service_group",
                "csat_score",
                "can_print",
                "category",
                "assignment_group",
                "checked_in",
                "checked_out",
                "comments",
                "company",
                "compatibility_dependencies",
                "consumer_type",
                "correlation_id",
                "cost",
                "cost_center",
                "cost_cc",
                "sys_created_on",
                "sys_created_by",
                "dns_domain",
                "service_owner_delegate",
                "delivery_manager",
                "department",
                "short_description",
                "discovery_source",
                "sys_domain",
                "sys_domain_path",
                "due",
                "due_in",
                "duplicate_of",
                "end_date",
                "environment",
                "estimated_rollup_spend",
                "u_facility_location",
                "fault_count",
                "first_discovered",
                "fqdn",
                "gl_account",
                "u_gxp",
                "has_estimated_rollup_spend",
                "u_hosting",
                "ip_address",
                "install_date",
                "invoice_number",
                "justification",
                "last_review_date",
                "lease_id",
                "life_cycle_stage",
                "life_cycle_stage_status",
                "location",
                "mac_address",
                "maintenance_schedule",
                "managed_by_group",
                "u_managed_ci",
                "u_managed_by_department",
                "u_managed_by_group",
                "manufacturer",
                "u_meta",
                "u_migrated_data",
                "model_id",
                "model_number",
                "monitor",
                "monitoring_requirements",
                "last_discovered",
                "x_nexsa_imc_nxt_engine",
                "x_nexsa_imc_nxt_platform",
                "number",
                "delivery_date",
                "order_date",
                "u_owned_by_department",
                "u_owning_service",
                "po_number",
                "parent",
                "u_patching_wave",
                "perf_score",
                "portfolio_status",
                "u_ot_plant",
                "prerequisites",
                "price_model",
                "price_unit",
                "purchase_date",
                "u_qualified",
                "unverified",
                "u_retired_date",
                "sla",
                "schedule",
                "u_self_reference",
                "serial_number",
                "service_level_requirement",
                "spm_service_portfolio",
                "skip_sync",
                "u_sourcing",
                "stakeholders",
                "start_date",
                "install_status",
                "service_status",
                "u_status_details",
                "subcategory",
                "u_support_service",
                "support_group",
                "supported_by",
                "sys_class_path",
                "sys_tags",
                "spm_taxonomy_node",
                "unit_description",
                "sys_updated_on",
                "sys_updated_by",
                "sys_mod_count",
                "user_group",
                "vendor",
                "version",
                "warranty_expiration"
            ],
            "query": "sys_idISNOTEMPTY",
            "tablename": "cmdb_ci_service",
            "reclimit": resultLimit,
            "recoffset": readStart
        },
        "header": {

            "sourcesystemid": "IDW"

        }
    }
    )
    headers = {
        'Api-Key': appKey,
        'Content-Type': appContentType,
        'Authorization': appAuth
    }

    response = requests.request("POST", url, headers=headers, data=payload)

    json_data = json.loads(response.text)

    df = json_normalize(json_data['result']['data'])

    if loopCount == 0:
        mdf = df
    else:
        mdf = mdf.append(df)
    loopCount += 1

    temp = temp + resultLimit

    # mdf.to_csv(r'C:\workdocs\PMO\API_RESPONSE\Cmdb_ci_service.csv'
    #           , index=False, header=True)

mdf.drop_duplicates()

mdf['short_description'] = mdf['short_description'].replace({r'\n': ''}, regex=True).replace({r'\r': ''},
                                                                                             regex=True).replace(
    {r'\r\n': ''}, regex=True)

mdf['comments'] = mdf['comments'].replace({r'\n': ''}, regex=True).replace({r'\r': ''},
                                                                           regex=True).replace(
    {r'\r\n': ''}, regex=True)

mdf['service_level_requirement'] = mdf['service_level_requirement'].replace({r'\n': ''}, regex=True).replace(
    {r'\r': ''},
    regex=True).replace(
    {r'\r\n': ''}, regex=True)


mdf['u_meta'] = mdf['u_meta'].replace({r'\n': ''}, regex=True).replace(
    {r'\r': ''},
    regex=True).replace(
    {r'\r\n': ''}, regex=True)

# mdf.drop(['short_description'], axis=1, inplace=True)
# print(short_desc_df)
# short_desc_df.to_csv(r'%s/SrcFiles/API_SRC/short_desc_.csv' % firstarg
#                     , index=False, quoting=1, header=True)

# mdf = mdf.merge(short_desc_df)

mdf.to_csv(r'%s/SrcFiles/API_SRC/Cmdb_ci_service.csv' % firstarg
           , index=False, quoting=1, header=True)

print("------process finished------")
