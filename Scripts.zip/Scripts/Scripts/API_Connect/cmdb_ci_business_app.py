#!/usr/bin/env python
# coding: utf-8


# !/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
# Description:python code to connect to getCiKeysMethod and getCiDetailsMethod methods from API. To  get a response from cmdb_ci_business_app class
# Pandas library used to convert response to CSV file.
#
# Date:09/06/2021
#
# Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
import pandas as pd
from pandas.io.json import json_normalize
from bs4 import BeautifulSoup

appKey = 'b4ea648c-f44a-4d53-925d-7b208985d34a'
appAuth = 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w='
appContentType = 'application/json'
getKeysurl = "https://send.roche.com/api/IT4IT/ServiceNow/cmdb/v2.2/v2/cmdb/getCiKeysMethod"
getCiDetailsurl = "https://send.roche.com/api/IT4IT/ServiceNow/cmdb/v2.2/v2/cmdb/getCiDetailsMethod"
ciTable = "cmdb_ci_business_app"
firstarg=sys.argv[1]

payload = json.dumps(
    {
        "content": {
            "query": "sys_class_name="+ciTable+""
        },
        "header": {
            "sourcesystemid": "IDW"
        }
    })
headers = {
    'Api-Key': appKey,
    'Content-Type': appContentType,
    'Authorization': appAuth
}

response = requests.request("POST", getKeysurl, headers=headers, data=payload)

json_data = json.loads(response.text)

# print(type(json_data))
loopCount = 0
recCount = json_data['result']['recAllCount']

while loopCount < recCount:

    # print(str(recCount) + str(loopCount))
    ciSys_ID = json_data['result']['ci_definition'][loopCount]['sys_id']
    # print(ciSys_ID)

    detailsPayload = json.dumps({
        "content": {
            "sys_class_name": ciTable,
            "sys_id": ciSys_ID
        },
        "header": {
            "sourcesystemid": "IDW",
            "targetsystemid": "GODW"
        }
    })
    # print(detailsPayload)
    detailsheaders = {
        'Api-Key': appKey,
        'Content-Type': appContentType,
        'Authorization': appAuth
    }

    detailsResponse = requests.request("POST", getCiDetailsurl, headers=detailsheaders, data=detailsPayload)

    detailsResponseJSON = json.loads(detailsResponse.text)

    df = json_normalize(detailsResponseJSON['result'][0]['cmdb_ci'])
    df.drop(['payload'], inplace=True, axis=1)

    payload_content = detailsResponseJSON['result'][0]['cmdb_ci']['payload']

    # print(payload_content)
    soup = BeautifulSoup(str(payload_content), "html.parser")
    for x in soup.find_all():
        if len(x.get_text(strip=True)) == 0:
            x.extract()
    # print(soup.prettify())
    # print("Soup data: "+ soup.attested_date.text)
    tagList = []
    for tag in soup.findAll(True):
        tagList.append(tag.name)
    #print(len(tagList))

    df['number'] = soup.number.text
    df['sys_updated_on'] = requests.utils.unquote(soup.sys_updated_on)
    df['install_type'] = soup.find('install_type')
    df['it_application_owner'] = requests.utils.unquote(soup.it_application_owner)
    df['sys_created_by'] = soup.find('sys_created_by')
    df['active'] = soup.find('active')
    df['sys_domain_path'] = soup.find('sys_domain_path')
    df['business_unit'] = soup.find('business_unit')
    df['u_investment_direction'] = soup.find('u_investment_direction')
    df['short_description'] = soup.short_description
    df['short_description']=df['short_description'].str.replace("%0D%0A", "")
    df['application_category'] = requests.utils.unquote(soup.application_category)
    df['u_application_architecture'] = soup.find('u_application_architecture')
    df['technology_stack'] = soup.find('technology_stack')
    df['active_user_count'] = soup.find('active_user_count')
    df['sys_updated_by'] = soup.find('sys_updated_by')
    df['portfolio'] = soup.find('portfolio')
    df['sys_created_on'] = requests.utils.unquote(soup.sys_created_on)
    df['sys_domain'] = soup.find('sys_domain')
    df['install_status'] = soup.find('install_status')
    df['u_self_reference'] = soup.find('u_self_reference')
    df['application_type'] = soup.find('application_type')
    df['u_managed_ci'] = soup.find('u_managed_ci')
    df['sys_class_path'] = requests.utils.unquote(soup.sys_class_path)
    df['cost_cc'] = soup.find('cost_cc')
    df['user_base'] = soup.find('user_base')
    df['environment'] = soup.find('environment')
    df['fault_count'] = soup.find('fault_count')

    #print(df)

    if loopCount == 0:
        mdf = df
    else:
        mdf = mdf.append(df)
    loopCount += 1
    # print(mdf)

mdf = mdf.replace(r'%20'
                  , ' ', regex=True).replace('%2C'
                                             , ',', regex=True).replace('%24'
                                                                        , '$', regex=True).replace('%21'
                                                                                                   , '$',
                                                                                                   regex=True)

mdf = mdf.replace('%26'
                  , '&', regex=True).replace('%3A'
                                             , ':', regex=True).replace('%3A'
                                                                        , ':', regex=True)

mdf = mdf.replace('%28'
                  , '(', regex=True).replace('%29', ')', regex=True)

mdf.to_csv(r'%s/SrcFiles/API_SRC/Cmdb_ci_business_app.csv' %firstarg
          , index=False, header=True)

#mdf.to_csv(r'C:\workdocs\PMO\API_RESPONSE/dftest.csv'
#           , index=False, header=True)
print("**********Proccess finished***********")
