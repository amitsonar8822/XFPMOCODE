#!/usr/bin/env python
# coding: utf-8

# In[1]:


#!/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to Resource_allocation API and get a response.Panda library used to convert response to CSV file
#
#Date:22/12/2020
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg=sys.argv[1]

loopID=1
recordExist=True

reclimit=10000
recoffset=1

print('InputPath: %s' %firstarg)


url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

while recordExist:
    print(loopID,recordExist,recoffset,reclimit)

    payload = json.dumps({
    "content": {
    "columnnames": [
      "end_date",
      "requested_man_days",
      "sys_domain",
      "task",
      "actual_hours",
      "requested_fte",
      "sys_created_by",
      "sys_updated_by",
      "assigned_cost",
      "number",
      "sys_id",
      "distribution_type",
      "requested_hours",
      "sys_created_on",
      "sys_updated_on",
      "actual_cost",
      "assigned_hours",
      "requested_cost",
      "start_date",
      "sys_mod_count",
      "allocated_hours",
      "allocated_cost",
      "resource_plan",
      "user",
      "booking_type",
      "user.user_name",
      "sys_tags"
    ],
    "query": "numberISNOTEMPTY",
    "tablename": "resource_allocation",
    "reclimit": ""+str(reclimit)+"",
    "recoffset": ""+str(recoffset)+""
  },
  "header": {
    "sourcesystemid": "IDW",
    "targetsystemid": "SNOW"
  }
})

    headers = {
      'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
      'Content-Type': 'application/json',
      'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w=',
      'Cookie': 'glide_user_route=glide.682dea81f49c65ab9e36110a1abb3c0a; BIGipServerpool_roche=2575425290.36158.0000; JSESSIONID=B91D59841362CBA84F3DDC1BAC2A6321'
    }
    response = requests.request("POST", url, headers=headers, data=payload)

    json_data = json.loads(response.text.encode('utf8'))
    df = json_normalize(json_data['result']['data'])

    if loopID==1:
        result=df

    else:
        result = result.append(df)


    recNum = json_data['result']['recCount']

    if recNum<1:
        recordExist = False
    recoffset=reclimit*loopID+1
    loopID=loopID+1


result.drop_duplicates()
result.to_csv(r'%s/SrcFiles/API_SRC/Resource_allocation.csv' %firstarg
          , index=False, header=True)



result['number'].count()


# In[94]:


recoffset


# In[ ]:
