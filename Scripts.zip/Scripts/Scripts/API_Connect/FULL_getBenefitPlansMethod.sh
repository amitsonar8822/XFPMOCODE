#!/bin/bash

#################################################################################################################
# Description: This script has been created to call getBenefitPlansMethod to get full list of projects based on criteria
# Author: Amit Sonar
# Date: 29/07/2020
#################################################################################################################

fp=`echo $(pwd)|cut -d'/' -f3`

source $1/ParFiles/API_param.conf

buffer_date=$(date +%Y-%m-%d -d "$BUFF_CRITERIA")

# Calculating 5 days back for data fetching

echo "updated_date":"$buffer_date"

# "updated_date":"'"$buffer_date"'"

curl --location --request POST "$getBenefitPlansUrl" \
--header 'Content-Type: application/json' \
--header 'Authorization: Basic '"$AUTHKEY"'' \
--header 'Api-Key: '"$APIKEY_PRD"'' \
--data '{
"content": {
},
"header": {
"sourcesystemid": "'"$SOURCESYSTEMID"'",
"recoffset" : 0,
"reclimit" : 100000
}
}' | sed 's/"sys_id"/\n"sys_id"/g' \
  |grep '"sys_id"' \
  |awk -F',' '{print $1}'|cut -d'"' -f 4 > $1/SrcFiles/API_SRC/FULL_BenefitPlansList.dat


