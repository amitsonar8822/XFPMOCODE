#!/usr/bin/python3
# -*- coding: utf-8 -*-
##############################################################################################################################
# Description:python code to connect to cmdb_rel_ci API and get a response.Panda library used to convert response to CSV file
#
# Date:17/06/2021
#
# Author:Amit Sonar
#
##############################################################################################################################


import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg = sys.argv[1]
loopCount = 0
appKey = 'b4ea648c-f44a-4d53-925d-7b208985d34a'
appAuth = 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w='
appContentType = 'application/json'
# print('InputPath: %s' %firstarg)
url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"
resultLimit = 3000
temp = 0
for x in range(1, 200):
    readStart = 1 + temp
    payload = json.dumps({
        "content": {
            "columnnames": [
                "sys_id",
                "child",
                "connection_strength",
                "parent",
                "percent_outage",
                "port",
                "type",
                "child.short_description",
                "child.category",
                "child.sys_class_name",
                "child.managed_by",
                "child.name",
                "child.owned_by",
                "child.u_owning_service",
                "child.po_number",
                "child.schedule",
                "child.start_date",
                "child.install_status",
                "child.vendor",
                "parent",
                "parent.x_avne2_atri_to_sn_active",
                "parent.category",
                "parent.sys_class_name",
                "parent.short_description",
                "parent.managed_by",
                "parent.name",
                "parent.owned_by",
                "parent.u_owning_service",
                "parent.po_number",
                "parent.schedule",
                "parent.start_date",
                "parent.install_status",
                "parent.vendor",
                "type.child_descriptor",
                "type.sys_class_name",
                "type.sys_created_on",
                "type.sys_created_by",
                "type.sys_name",
                "type.end_point",
                "type.name",
                "type.sys_package",
                "type.parent_descriptor",
                "type.sys_policy",
                "type.sys_update_name",
                "type.sys_updated_on",
                "type.sys_updated_by",
                "type.sys_mod_count"
            ],
            "query": "sys_idISNOTEMPTY",
            "tablename": "cmdb_rel_ci",
            "reclimit": resultLimit,
            "recoffset": readStart
        },
        "header": {

            "sourcesystemid": "IDW"

        }
    }
    )
    headers = {
        'Api-Key': appKey,
        'Content-Type': appContentType,
        'Authorization': appAuth
    }

    response = requests.request("POST", url, headers=headers, data=payload)

    json_data = json.loads(response.text)

    df = json_normalize(json_data['result']['data'])

    if loopCount == 0:
        mdf = df
    else:
        mdf = mdf.append(df)
    loopCount += 1

    temp = temp + resultLimit

    # mdf.to_csv(r'C:\workdocs\PMO\API_RESPONSE\Cmdb_rel_ci.csv'
    #           , index=False, header=True)

mdf.drop_duplicates()

mdf['child.short_description'] = mdf['child.short_description'].replace({r'\n': ''}, regex=True).replace(
    {r'\r': ''},
    regex=True).replace(
    {r'\r\n': ''}, regex=True)

mdf['parent.short_description'] = mdf['parent.short_description'].replace({r'\n': ''}, regex=True).replace(
    {r'\r': ''},
    regex=True).replace(
    {r'\r\n': ''}, regex=True)

mdf['child.name'] = mdf['child.name'].replace({r'\n': ''}, regex=True).replace(
    {r'\r': ''},
    regex=True).replace(
    {r'\r\n': ''}, regex=True)

mdf['parent.name'] = mdf['parent.name'].replace({r'\n': ''}, regex=True).replace(
    {r'\r': ''},
    regex=True).replace(
    {r'\r\n': ''}, regex=True)

mdf['parent'] = mdf['parent'].replace({r'\n': ''}, regex=True).replace(
    {r'\r': ''},
    regex=True).replace(
    {r'\r\n': ''}, regex=True)

mdf['child'] = mdf['child'].replace({r'\n': ''}, regex=True).replace(
    {r'\r': ''},
    regex=True).replace(
    {r'\r\n': ''}, regex=True)

mdf.to_csv(r'%s/SrcFiles/API_SRC/Cmdb_rel_ci.csv' % firstarg
           , index=False, header=True)

print("------process finished------")
