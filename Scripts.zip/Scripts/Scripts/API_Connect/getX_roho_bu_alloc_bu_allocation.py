#!/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to Resource_plan API and get a response.Panda library used to convert response to CSV file
#
#Date:17/12/2020
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
from pandas.io.json import json_normalize

firstarg=sys.argv[1]

print('InputPath: %s' %firstarg)

url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

payload="{\r\n  \"content\": {\r\n    \"columnnames\": [\r\n      \"sys_id\",\r\n      \"task\",\"business_unit\",\"allocation_percent\",\"spending_bu\",\"planned_cost\",\"sys_mod_count\",\"sys_updated_by\",\"sys_updated_on\",\"sys_tags\",\"portfolio\",\"planned_cost_opex\",\"planned_cost_capex\",\"budget_opex\",\"domain\",\"description\",\"sys_created_by\",\"sys_created_on\",\"budget_capex\",\"actual_cost_opex\",\"actual_cost_capex\",\"actual_cost\",\"planned_benefit\",\"actual_benefit\",\"budget\"\r\n\r\n    ],\r\n    \"query\": \"sys_idISNOTEMPTY\",\r\n    \"tablename\": \"x_roho_bu_alloc_bu_allocation\"\r\n  },\r\n  \"header\": {\r\n    \"sourcesystemid\": \"IDW\",\r\n    \"targetsystemid\": \"SNOW\"\r\n  }\r\n}\r\n"
headers = {
  'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
  'Content-Type': 'application/json',
  'Authorization': 'Basic aW50Z3JvdW06WEZQTU8yMDIwYXNk',
  'Cookie': 'glide_user_route=glide.01513c8fdad6c5269a78dacf21189b54; BIGipServerpool_roche=2457984778.34878.0000; JSESSIONID=DEE831E9C60C564EE2EE3CF05EDAAC2F; glide_session_store=E59A5CAC1B1AA850311931DA9B4BCBF8'
}

response = requests.request("POST", url, headers=headers, data=payload)

json_data = json.loads(response.text.encode('utf8'))
df = json_normalize(json_data['result']['data'])

df.to_csv(r'%s/SrcFiles/API_SRC/X_roho_bu_alloc_bu_allocation.csv' %firstarg
          , index=False, header=True)
