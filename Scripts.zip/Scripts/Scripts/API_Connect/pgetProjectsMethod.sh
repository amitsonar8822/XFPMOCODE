#!/bin/bash

#################################################################################################################
# Description: This script has been created to call getProjectsMethod to get list of projects based on criteria
# ENV: TEST
# Author: Amit Sonar
# Date: 27/03/2020
#################################################################################################################

fp=`echo $(pwd)|cut -d'/' -f3`

source /infa_shared/"$fp"/OSP_DIR/idw0428/ParFiles/API_param.conf

buffer_date=$(date +%Y-%m-%d -d "$BUFF_CRITERIA")

# Calculating 5 days back for data fetching


curl --location --request POST "$getProjectsUrl" \
--header 'Content-Type: application/json' \
--header 'Api-Key: '"$APIKEY_PRD"'' \
--header 'Authorization: Basic '"$AUTHKEY"'' \
--data '{
"content": {
"active": "true"
},
"header": {
"sourcesystemid": "'"$SOURCESYSTEMID"'",
"recoffset" : 0,
"reclimit" : 100000
}
}' | grep -o '\bPRJ\w*' > /infa_shared/INT_GRD_TEST/OSP_DIR/idw0428/SrcFiles/API_SRC/ProjectList.dat
