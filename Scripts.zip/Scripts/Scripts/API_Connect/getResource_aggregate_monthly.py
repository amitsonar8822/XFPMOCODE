#!/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
#Description:python code to connect to resource_aggregate_monthly API and get a response.Panda library used to convert response to CSV file
#
#Date:23/12/2020
#
#Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
from pandas.io.json import json_normalize
from datetime import date
from datetime import datetime  
from datetime import timedelta


today_date = date.today().replace(day=1).isoformat()
print(today_date)
t_date = date.today() + timedelta(days=365)
afteroneyear_date=t_date.isoformat()
print(afteroneyear_date)
  

firstarg=sys.argv[1]

print('InputPath: %s' %firstarg)


url = "https://send.roche.com/api/IT4IT/ServiceNow/genericapi/v1.0/hlr_generic_api/getKeys"

payload="{\r\n  \"content\": {\r\n    \"columnnames\": [\r\n\"category\",\r\n\"hours\",\r\n\"man_days\",\r\n\"month_starts_on\",\r\n\"task\",\t\r\n\"user\",\r\n\"user.user_name\"\r\n    ],\r\n    \"query\": \"category=Capacity^month_starts_on>"'$today_date'"\",\r\n    \"tablename\": \"resource_aggregate_monthly\",\r\n    \"reclimit\": \"100000\"\r\n  },\r\n  \"header\": {\r\n    \"sourcesystemid\": \"IDW\",\r\n    \"targetsystemid\": \"GODW\"\r\n  }\r\n}"


headers = {
  'Api-Key': 'b4ea648c-f44a-4d53-925d-7b208985d34a',
  'Content-Type': 'application/json',
  'Authorization': 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w=',
  'Cookie': 'glide_user_route=glide.682dea81f49c65ab9e36110a1abb3c0a; BIGipServerpool_roche=2575425290.36158.0000; JSESSIONID=A469377DFF0CA32C789C39E4EC3B8FE5; glide_session_store=A307C8491B91E4D0488062CCAB4BCBDB'
}


response = requests.request("POST", url, headers=headers, data=payload)

#print(response.text.encode('utf8'))

json_data = json.loads(response.text.encode('utf8'))
df = json_normalize(json_data['result']['data'])

df.to_csv(r'%s/SrcFiles/API_SRC/Resource_aggregate_monthly.csv' %firstarg
          , index=False, header=True)
