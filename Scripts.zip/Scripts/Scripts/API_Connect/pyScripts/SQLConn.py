#!/usr/bin/python3

import pyodbc 
conn = pyodbc.connect('Driver={/opt/informatica/Informatica102/ODBC7.1/lib/DWsqls28.so};'
                      'Server=RBAMV451716\OPSDWHQAT,57100;'
                      'Database=OPSDWH;'
                      'Trusted_Connection=yes;')

cursor = conn.cursor()
cursor.execute('SELECT top 1 * FROM from [OPSDWH].[sap].[V_LOCAL_VENDOR]')

for row in cursor:
    print(row)