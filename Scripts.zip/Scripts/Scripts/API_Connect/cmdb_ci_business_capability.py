#!/usr/bin/env python
# coding: utf-8


# !/usr/bin/python
# -*- coding: utf-8 -*-
##############################################################################################################################
# Description:python code to connect to getCiKeysMethod and getCiDetailsMethod methods from API. To  get a response from cmdb_ci_business_app class
# Pandas library used to convert response to CSV file.
#
# Date:23/06/2021
#
# Author:Amit Sonar
#
##############################################################################################################################
import sys
import requests
import json
import pandas as pd
from pandas.io.json import json_normalize
from bs4 import BeautifulSoup

appKey = 'b4ea648c-f44a-4d53-925d-7b208985d34a'
appAuth = 'Basic aW50Z3JvdW06aGVvd0F4ZXdhMjEzNC1KdWlrd2w='
appContentType = 'application/json'
getKeysurl = "https://send.roche.com/api/IT4IT/ServiceNow/cmdb/v2.2/v2/cmdb/getCiKeysMethod"
getCiDetailsurl = "https://send.roche.com/api/IT4IT/ServiceNow/cmdb/v2.2/v2/cmdb/getCiDetailsMethod"
ciTable = 'cmdb_ci_business_capability'
firstarg=sys.argv[1]

payload = json.dumps(
    {
        "content": {
            "query": "sys_class_name=" + ciTable + ""
        },
        "header": {
            "sourcesystemid": "IDW"
        }
    })
headers = {
    'Api-Key': appKey,
    'Content-Type': appContentType,
    'Authorization': appAuth
}

response = requests.request("POST", getKeysurl, headers=headers, data=payload)

json_data = json.loads(response.text)

# print(type(json_data))
loopCount = 0
recCount = json_data['result']['recAllCount']

while loopCount < recCount:

    # print(str(recCount) + str(loopCount))
    ciSys_ID = json_data['result']['ci_definition'][loopCount]['sys_id']
    # print(ciSys_ID)

    detailsPayload = json.dumps({
        "content": {
            "sys_class_name": ciTable,
            "sys_id": ciSys_ID
        },
        "header": {
            "sourcesystemid": "IDW"
        }
    })
    # print(detailsPayload)
    detailsheaders = {
        'Api-Key': appKey,
        'Content-Type': appContentType,
        'Authorization': appAuth
    }

    detailsResponse = requests.request("POST", getCiDetailsurl, headers=detailsheaders, data=detailsPayload)

    detailsResponseJSON = json.loads(detailsResponse.text)

    df = json_normalize(detailsResponseJSON['result'][0]['cmdb_ci'])
    df.drop(['payload'], inplace=True, axis=1)

    payload_content = detailsResponseJSON['result'][0]['cmdb_ci']['payload']

    # print(payload_content)
    soup = BeautifulSoup(payload_content, "html.parser")
    for x in soup.find_all():
        if len(x.get_text(strip=True)) == 0:
            x.extract()
    # print(soup.prettify())
    # print("Soup data: "+ soup.attested_date.text)
    tagList = []
    for tag in soup.findAll(True):
        tagList.append(tag.name)
    #print(len(tagList))

    df['parent'] = soup.parent
    df['sys_updated_on'] = requests.utils.unquote(soup.sys_updated_on)
    df['sys_created_by'] = soup.sys_created_by
    df['active'] = soup.active
    df['sys_domain_path'] = soup.sys_domain_path
    df['leaf_node'] = soup.leaf_node
    df['business_unit'] = soup.business_unit
    df['attested_by'] = soup.attested_by
    df['hierarchy_id'] = soup.hierarchy_id
    df['short_description'] = soup.short_description
    df['short_description']=df['short_description'].str.replace("%0D%0A", "")
    df['sys_updated_by'] = soup.sys_updated_by
    df['sys_created_on'] = requests.utils.unquote(soup.sys_created_on)
    df['sys_domain'] = soup.sys_domain
    df['u_self_reference'] = soup.u_self_reference
    df['hierarchy_level'] = soup.hierarchy_level
    df['u_managed_ci'] = soup.u_managed_ci
    df['sys_class_path'] = soup.sys_class_path
    df['use_for_assessment'] = soup.use_for_assessment
    df['cost_cc'] = soup.cost_cc
    df['fault_count'] = soup.fault_count

    #print(df)

    if loopCount == 0:
        mdf = df
    else:
        mdf = mdf.append(df)
    loopCount += 1
    # print(mdf)

mdf = mdf.replace(r'%20'
                  , ' ', regex=True).replace('%2C'
                                             , ',', regex=True).replace('%24'
                                                                        , '$', regex=True).replace('%21'
                                                                                                   , '$',
                                                                                                   regex=True)

mdf = mdf.replace('%5D'
                  , ']', regex=True).replace('%5B'
                                             , '[', regex=True).replace('%27'
                                                                        , "'", regex=True)
mdf = mdf.replace('%26'
                  , '&', regex=True).replace('%3A'
                                             , ':', regex=True).replace('%AD'
                                                                        , '', regex=True)
mdf = mdf.replace('%3F'
                  , '?', regex=True).replace('%0A'
                                             , '', regex=True).replace('%3E'
                                                                        , '>', regex=True)
                                                                        
mdf = mdf.replace('%3B'
                  , ':', regex=True).replace('%23'
                                             , '#', regex=True).replace('%22'
                                                                        , '"', regex=True)
mdf = mdf.replace('%28'
                  , '(', regex=True).replace('%29', ')', regex=True)

mdf.to_csv(r'%s/SrcFiles/API_SRC/Cmdb_ci_business_capability.csv' %firstarg
          , index=False, header=True)

#mdf.to_csv(r'C:\workdocs\PMO\API_RESPONSE/dftest_capa.csv'
#           , index=False, header=True)
print("**********Proccess finished***********")
