#!/bin/bash

############################################################################################################################
# Description: This script has been created to create filelist from DataMart directory to give input to Informatica session
# Author: Amit Sonar
# Date: 26/02/2021
############################################################################################################################



FILES_DIR=$1/SrcFiles/API_SRC/CostPlanParts
TARGET_DIR=$1/SrcFiles/API_SRC/CostPlanParts

cd /
cd $FILES_DIR
if [ -n "$(ls -A $FILES_DIR/*.csv 2>/dev/null)" ]

then

        find "$PWD" -name \*.csv > $TARGET_DIR/CostPlanFileList.txt

else

                echo 'no files available'
                exit 0

fi

