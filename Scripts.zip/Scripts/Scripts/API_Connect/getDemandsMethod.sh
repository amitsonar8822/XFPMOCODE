#!/bin/bash

#################################################################################################################
# Description: This script has been created to call getDemandsMethod to get list of projects based on criteria
# Author: Amit Sonar
# Date: 27/03/2020
#################################################################################################################

fp=`echo $(pwd)|cut -d'/' -f3`

source $1/ParFiles/API_param.conf

buffer_date=$(date +%Y-%m-%d -d "$BUFF_CRITERIA")

# Calculating 5 days back for data fetching

echo "updated_date":"$buffer_date"

curl --location --request POST "$getDemandsUrl" \
--header 'Content-Type: application/json' \
--header 'Api-Key: '"$APIKEY_PRD"'' \
--header 'Authorization: Basic '"$AUTHKEY"'' \
--data '{
"content": {
"active": "true",
"updated_date":"'"$buffer_date"'"
},
"header": {
"sourcesystemid": "'"$SOURCESYSTEMID"'",
"recoffset" : 0,
"reclimit" : 100000
}
}' | grep -o '\bDMN\w*' > $1/SrcFiles/API_SRC/DemandList.dat

