#!/bin/bash

##########################################################################################
# Description: This script has been created to remove and replace unnecessary Line feeders and carriage return
# Author: Amit Sonar
# Date: 16/07/2020
##########################################################################################

cd /infa_shared/INT_GRD_TEST/OSP_DIR/idw0428/SrcFiles/POC
inputfile=$1

tr '\n' ' ' < $1 | tr '\r' '\n' > POC_TAB.csv




