#!/bin/bash

##########################################################################################
# Description: This script has been created to start DataMart workflow automatically
# Author: Amit Sonar
# Date: 27/04/2020
##########################################################################################



path=$ENVIRONMENT/ParFiles

source /infa_shared/INT_GRD_PROD/OSP_DIR/idw0428/ParFiles/ETL_param.conf

pmcmd startworkflow -sv $service -d $domain -usd $sec_domain -u $user -p $password -f $folder $workflow_resource_dm